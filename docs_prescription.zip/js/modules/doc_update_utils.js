function insertTable( {col1, col2, startIndex}) {

    let table_arr = []
    table_arr.push(
        {
            insertTable: {
                rows: col1.length,
                columns: 2,
                location: {
                    index: startIndex
                },

            }
        },
    )

    let curr_index = startIndex
    for(let i  = 0; i < col1.length; i++){
        curr_index += i==0?4:3;
        table_arr.push(
            {
                insertText: {
                    text: col1[i],
                    location: {
                        index: curr_index, // Modified
                    },
                }
            },
        )

        curr_index += col1[i].length + 2

        table_arr.push(
            {
                insertText: {
                    text: col2[i],
                    location: {
                        index: curr_index, // Modified
                    },
                }
            },
        )
        curr_index += col2[i].length

    }

    return {table_arr,curr_index};
}

function insertText({startIndex, text}){
    let text_arr = [   {
        insertText: {
            text: text,
            location: {
                index: startIndex, // Modified
            },
        }
    },

    {
        updateParagraphStyle: {
            paragraphStyle: {
                alignment: "START",
                direction: "RIGHT_TO_LEFT",

            },
            fields: "alignment, direction",
            range: {
                startIndex: startIndex,
                endIndex: startIndex + text.length
            }
        }
    },

    {
        updateTextStyle: {
            textStyle: {
                bold: true,
                underline: true,
                fontSize: {
                    magnitude: 12.0,
                    unit: "PT"
                },
                weightedFontFamily: {
                    fontFamily: "Times New Roman"
                }
            },
            fields: "fontSize, weightedFontFamily, bold, underline",
            range: {
                startIndex: startIndex,
                endIndex: startIndex + text.length
            }
        }

    }]


    return {text_arr,curr_index:startIndex + text.length};

}

export {insertTable, insertText}